// id = Nimi, size = ringi suurus
export const nodes = [
  { id: 'Kodu ruuter', size: 40, distance: 50 },
  { id: 'Minu arvuti', size: 20, distance: 50 },
  { id: 'Telekas', size: 20, distance: 50 },
  { id: 'Telefon 1', size: 10, distance: 10 },
  { id: 'Telefon 2', size: 10, distance: 50 },
];

export const links = [
  { source: 0, target: 1 }, // Kodu ruuter → Minu arvuti
  { source: 0, target: 2 }, // Kodu ruuter → Telekas
  { source: 0, target: 3 },	// Kodu ruuter → telefon 1
  { source: 0, target: 4 }, // Kodu ruuter → telef